export type AVATAR_SIZE = 'large' | 'xlarge';
