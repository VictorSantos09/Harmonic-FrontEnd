export * from './details-conteudo.component';
