import { Component } from '@angular/core';

@Component({
  selector: 'app-table-podcast',
  standalone: true,
  imports: [],
  templateUrl: './table-podcast.component.html',
  styleUrl: './table-podcast.component.scss'
})
export class TablePodcastComponent {

}
