export * from './carousel.component';

