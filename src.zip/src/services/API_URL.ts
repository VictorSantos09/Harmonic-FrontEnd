export class API_URL {
  static readonly URL = 'https://localhost:7057/';
}
