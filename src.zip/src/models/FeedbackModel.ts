export class FeedbackModel {
  constructor(
    public id: number,
    public totalCurtidas: number,
    public totalGosteis: number
  ) {}
}
