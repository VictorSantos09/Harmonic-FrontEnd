export class PaisModel {
  constructor(public id: number, public nome: string) {}
}
