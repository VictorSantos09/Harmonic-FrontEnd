export class TipoConteudoModel {
  constructor(public id: number, public nome: string) {}
}
