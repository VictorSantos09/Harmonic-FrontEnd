export class ROUTES_CNT {
  static readonly RADIO = '/radio';
  static readonly PODCAST = '/podcast';
  static readonly CONTEUDO = '/conteudo';
  static readonly CADASTRO = '/register';
  static readonly CONSULTAR_CONTA = '/conta';
  static readonly CONTEUDO_INFORMACAO = '/information';
  static readonly HOMEPAGE = '/';
}
